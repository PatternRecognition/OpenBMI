function tcpipmex(varargin)
  
  disp('You must compile tcpipmex.c for your platform!');
  disp('Do this with: mex tcpipmex.c');
  error 'No tcpipmex binary file!'
